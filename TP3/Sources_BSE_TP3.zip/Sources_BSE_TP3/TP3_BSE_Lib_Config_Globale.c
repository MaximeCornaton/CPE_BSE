/******************************************************************************
; 	FILE NAME  	: TP2_BSE_Lib_Config_Globale.C
; 	TARGET MCUs	: C8051F020, 
; 	DESCRIPTION	: Configurations GLOBALES pour le 8051F020
;
; 	REVISION 1.0
;   Ce fichier contient les codes de configuration globale du 8051F020
;     - Configuration de l'horloge syst�me SYSCLK
;     - Configuration des broches du 80851F020
;     - Configuration Reset et watchdog
*/
//******************************************************************************

#include "C8051F020.h"
#include "c8051F020_SFR16.h"
#include "TP3_BSE_Lib_Config_Globale.h"

// Peripheral specific initialization functions,
// Called from the Init_Device() function

//-----------------------------------------------------------------------------
// D�validation du watchdog
//-----------------------------------------------------------------------------
void Reset_Sources_Init()
{
	// La configuration des registres WDTCN  sera �tudi�e plus tard
	 WDTCN = 0xDE;
	 WDTCN = 0XAD;
}

//-----------------------------------------------------------------------------
// Configuration des Ports d'entr�e-sorties
//-----------------------------------------------------------------------------

void Port_IO_Init()
{
    // P0.0  -  Congiguration PIO - TX0 (UART0)
    // P0.1  -  Congiguration PIO - RX0 (UART0)
    // P0.2  -  Congiguration PIO - INT0 (Tmr0)
    // P0.3  -  Congiguration PIO - INT1 (Tmr1)
    // P0.4  to P7.7 - Mode GPIO par d�faut 
 
// La configuration des registres XBR sera �tudi�e plus tard
    XBR0      = 0x04; // Configuration Hors du cadre TP1-BSE
    XBR1      = 0x14; // Configuration Hors du cadre TP1-BSE
    XBR2      = 0x40; // Configuration Hors du cadre TP1-BSE


	  P1MDOUT |= (1<<6);  // P1.6  en Push Pull
	
// Config pour gestion bouton poussoir
	     P3 |= (1<<7); // Mise � 1 de P3.7
       P3MDOUT &= ~(1<<7); // P3.7 en Drain ouvert
// Config pour drapeaux mat�riels d'interruption	
        P2MDOUT |= (1<<4);  // P2.4 en Push Pull
	      P74OUT |= (1<<5);   // P6.4 � P6.7 en PP
	      P2 &= ~(1<<4);       // P2.4 mis � z�ro
        P6 &= ~(1<<4); 	     // P6.4 mis � z�ro
	      P3MDOUT |= (1<<5);  // P3.5 en Push Pull
	      P3 &= ~(1<<5);       // 3.5 mis � z�ro
}



//-----------------------------------------------------------------------------
// Initialisation globale du Microcontr�leur - 
//-----------------------------------------------------------------------------
void Init_Device(void)
{
    Reset_Sources_Init();
    Port_IO_Init();
}




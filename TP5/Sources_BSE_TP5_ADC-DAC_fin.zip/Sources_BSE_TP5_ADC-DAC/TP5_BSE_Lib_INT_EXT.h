/*---------------------------------------------------------------------------
;   FILE NAME  	: TP5_Lib_INT_EXT.H
; 	TARGET MCUs	: C8051F020, 
; 	DESCRIPTION	: 
;
; 	REVISION 1.0
;
;---------------------------------------------------------------------------*/

#ifndef __TP5_Lib_INT_EXT__
#define __TP5_Lib_INT_EXT__

void Config_INT6(void);
void Config_INT7(void);

#endif